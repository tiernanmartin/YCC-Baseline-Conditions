Shiny Dashboard
===============

*Travis:* [![Travis-CI Build Status](https://travis-ci.org/rstudio/shinydashboard.svg?branch=master)](https://travis-ci.org/rstudio/shinydashboard)

*AppVeyor:* [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/rstudio/shinydashboard?branch=master&svg=true)](https://ci.appveyor.com/project/rstudio/shinydashboard)

## Installation

To install from CRAN:

```R
install.packages("shinydashboard")
```

See the documentation at http://rstudio.github.io/shinydashboard/
